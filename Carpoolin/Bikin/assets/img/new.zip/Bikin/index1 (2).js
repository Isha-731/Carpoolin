var animation = bodymovin.loadAnimation({
    container: document.getElementById('animContainer'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: 'C:\Users\Dell\Downloads\Bikin\Animation - 1709275343781.json' // lottie file path
  })